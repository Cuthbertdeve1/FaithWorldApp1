

<!DOCTYPE html>
<html lang="en-US">
<head>
<title>prayer request</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />




<!-- jQuery -->
<script type="text/javascript" src="pagesMenu/src/libs/jquery/jquery.js"></script>

<!-- SmartMenus jQuery plugin -->
<script type="text/javascript" src="pagesMenu/jquery.smartmenus.js"></script>


<script type="text/javascript">
	$(function() {
		$('#main-menu').smartmenus({
			subMenusSubOffsetX: 1,
			subMenusSubOffsetY: -8
		});
	});
</script>


<link rel="stylesheet" type="text/css" href="alpages.css">


<link href="pagesMenu/src/css/sm-core-css.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="java_Script1/Mytheme.min.css">

<link href="pagesMenu/src/css/sm-blue/sm-blue.css" rel="stylesheet" type="text/css" />

<link href="pageMenu/src/libs/demo-assets/demo.css" rel="stylesheet" type="text/css" />
<link rel ="stylesheet" type="text/css" href="formzDesign.css">
</head>
<body>
<?php
   if(isset($_POST['username']) && isset($_POST['email']) &&isset($_POST['phone']) &&isset($_POST['comments'])){
	   $username =$_POST['username'];
	   $email =$_POST['email'];
	   $phone =$_POST['phone'];
	   $comments =$_POST['comments'];
	   
	   if(!empty($username) && !empty($email) && !empty($phone)&& !empty($comments)){
		   $to = 'cartbertkurangana@gmail.com';
		   $subject = 'Prayer request submitted.';
		   $body = $username."\n".$comments;
		   $headers ='From:'.$email;
		   ?>
		   <h1><?php
		   echo'request send thank you';
	   }else{
		   echo'All fields are required';
	   }
   }
  
  ?>
</h1>
<header width="100%;"height="100%;">
<div id="h_log">
<img id="logo" src="FWMA_PIC/fwm.png"></img>
<div id="h_con">

</div>
</div>
</header>

<nav id="main-nav" role="navigation">
  
  <ul id="main-menu" class="sm sm-blue">
<!--<div id="nav">
  <div id="nav_wrapper">/-->
    
      <li><a href="index.html">Welcome</a>
	  </li>
	       <li><a href="conferance.html">Conferance</a></li>
		   <li><a href="bible_college.html">Bible College</a></li>
		   <li><a href="itinerary.html">Itinerary</a></li>
		   
		   <li><a href="donate.html">Donate</a></li>
	     <li>
       <a href="videos.html">Videos</a></li>
     </ul>
   <!-- </div>
</div>/-->

</nav>
<section>
   <div id="my_pics">

              <div id="bishops"><img src="FWMA_PIC/bishop.jpg" width="100%" height="30%"
			  ></img></div>
               
      
  </div>
  </section>
<article>

    <div style="text-align:center">
	     
	      <h2 style="text-align:center; margin-bottom:20px;">Not Functioning For Now!!</h2>
		     <form method="POST" action="prayer_request.php">
	<span class="labelName">Enter You Name:</span> <input type="text" name="username" id="name" maxlength="40" title="you name" required><br>
	<span class="labelEmail">Enter You Email:</span><input type="email" name="email"><br>
  <p style="margin-bottom:20px"> <span class="labelPhone">Enter Phone Number</span><input type="tel" name="phone" maxlength="15" required><br /></p>
  <p style="width:120%"><textarea name="comments" required cols="20" rows="6" maxlength="500" title="request"></textarea><br /></p>
 <p style="width:120%;margin-top:20px;"><input type="submit" value="send">
 <input type="reset" value="reset"></p>
  </form>		           
  </div>        
	
</article>
 <footer>
   <div id="footend"> 
   <div class ="prmenu_container" id="footer_container">
   <nav>
   <ul>
	   <li>
	  <a href="https://www.facebook.com/BishopDr.B.Manjoro/"><img src="FWMA_PIC/fb.gif" width="10%" height="auto"/></a>
	  
		</li>
	   <li>
	 <a href="https://twitter.com/intent/follow?original_referer=http%3A%2F%2Fbishopmanjoro.org%2Ffwm%2Findex.php&ref_src=twsrc%5Etfw&screen_name=bishopmanjoro&tw_p=followbutton">  <img src="FWMA_PIC/twt.gif" width="10%" height="auto"/></a> 
	
	   </li>
	   <li>
	   <a href="https://www.youtube.com/results?search_query=bishop+manjoro"> <img src="FWMA_PIC/email.gif" width="10%" height="auto"/></a>
	   
	   </li>
   </ul>
   </nav>
       
	   
	   
      </div>
	    <div id="copy">
		   <small>copywrite © Faith World Ministries</small>
    </div>
	</div>

 </footer>
</body>

</html>